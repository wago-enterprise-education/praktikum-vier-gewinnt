#ifndef COLOR_H
#define COLOR_H

enum struct Color{
    OFF,
    RED,
    GREEN,
    FLASH_RED,
    FLASH_GREEN
};

#endif